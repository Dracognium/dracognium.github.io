import flet as ft
from datetime import datetime
def main(page: ft.Page):
    totinh = datetime(2019,10,19)
    hientai = datetime.now()
    duration = hientai - totinh
    days = duration.days
    
    page.fonts = {"luving" : f"/fonts/luving.ttf"}
    page.title = "Images Example"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.padding = 0
    page.window_width = 414
    page.window_height = 896
    page.update()

    page.add(
        ft.Container(
            image_src = f"/images/bg.jpg",
            image_fit = ft.ImageFit.COVER,
            expand = True,
            width=414,
            height=896,
            alignment=ft.alignment.Alignment(0,-0.25),
            content=ft.Text(
                value = f"{days} days moahhhh!",
                size = 40,
                weight=ft.FontWeight.BOLD,
                italic=True,
                font_family="luving",
                color= ft.colors.RED,
            ),
        )
    )

    
    page.update()

ft.app(target=main,assets_dir="assets")